function function1() {
	window.open('assets/resume-example.pdf');
}